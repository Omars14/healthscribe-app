module.exports=[7035,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_transcriptions_route_actions_bb688ca6.js.map