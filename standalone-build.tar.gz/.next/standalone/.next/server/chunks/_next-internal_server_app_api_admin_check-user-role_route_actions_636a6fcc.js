module.exports=[85634,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_check-user-role_route_actions_636a6fcc.js.map