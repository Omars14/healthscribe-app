module.exports=[78339,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_admin_transcriptions_page_actions_3f03e313.js.map