module.exports=[662,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_medical-transcription_page_actions_669e8ed9.js.map