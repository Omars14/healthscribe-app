module.exports=[63498,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_admin_users-simple_page_actions_5c26f849.js.map