module.exports=[71267,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_test-db_page_actions_5869805d.js.map