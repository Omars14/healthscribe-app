module.exports=[4015,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_transcriptions_page_actions_4717fcc5.js.map