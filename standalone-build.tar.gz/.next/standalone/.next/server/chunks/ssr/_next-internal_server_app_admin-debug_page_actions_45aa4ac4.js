module.exports=[87034,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin-debug_page_actions_45aa4ac4.js.map