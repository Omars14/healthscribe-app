module.exports=[71789,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_workspace-transcriptions_route_actions_8d74bfe8.js.map