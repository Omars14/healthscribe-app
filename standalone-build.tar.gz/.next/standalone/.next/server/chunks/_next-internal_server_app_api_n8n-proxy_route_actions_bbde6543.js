module.exports=[1695,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_n8n-proxy_route_actions_bbde6543.js.map