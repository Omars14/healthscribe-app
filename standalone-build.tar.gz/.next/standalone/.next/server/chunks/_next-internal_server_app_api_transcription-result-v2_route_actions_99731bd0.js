module.exports=[68987,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_transcription-result-v2_route_actions_99731bd0.js.map