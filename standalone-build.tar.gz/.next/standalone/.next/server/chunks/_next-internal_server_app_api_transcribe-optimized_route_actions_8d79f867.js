module.exports=[12806,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_transcribe-optimized_route_actions_8d79f867.js.map