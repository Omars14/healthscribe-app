module.exports=[34579,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_reviews_comments_route_actions_51a2b603.js.map