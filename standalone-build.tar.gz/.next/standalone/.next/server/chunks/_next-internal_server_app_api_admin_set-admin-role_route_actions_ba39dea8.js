module.exports=[39606,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_set-admin-role_route_actions_ba39dea8.js.map