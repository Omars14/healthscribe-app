module.exports=[53804,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_transcriptions_route_actions_7ba3b26e.js.map