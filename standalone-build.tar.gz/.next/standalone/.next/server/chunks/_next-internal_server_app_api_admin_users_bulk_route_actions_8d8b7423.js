module.exports=[93120,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_users_bulk_route_actions_8d8b7423.js.map