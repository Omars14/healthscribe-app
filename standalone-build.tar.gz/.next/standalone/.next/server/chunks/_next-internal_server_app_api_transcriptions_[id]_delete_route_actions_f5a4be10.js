module.exports=[84495,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_transcriptions_%5Bid%5D_delete_route_actions_f5a4be10.js.map