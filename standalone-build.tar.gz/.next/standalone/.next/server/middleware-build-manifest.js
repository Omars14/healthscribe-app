globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/74be00a463cf81df.js",
    "static/chunks/35b6194a18097103.js",
    "static/chunks/8e7f8891ee3dca58.js",
    "static/chunks/0ff423a9fcc0186e.js",
    "static/chunks/95f61293c620e474.js",
    "static/chunks/turbopack-e9341c322bcfec09.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];