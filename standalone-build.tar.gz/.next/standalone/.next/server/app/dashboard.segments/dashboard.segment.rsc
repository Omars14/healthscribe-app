1:"$Sreact.fragment"
2:I[92825,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/64c0a5e3a0354479.js"],"ClientSegmentRoot"]
3:I[39126,["/_next/static/chunks/ac5a9642c87a044d.js","/_next/static/chunks/e7cd30e6131a4d4c.js","/_next/static/chunks/427011f3140bc67e.js"],"default"]
4:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/64c0a5e3a0354479.js"],"default"]
5:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/64c0a5e3a0354479.js"],"default"]
0:{"buildId":"production-build","rsc":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/427011f3140bc67e.js","async":true}]],["$","$L2",null,{"Component":"$3","slots":{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]},"serverProvidedParams":{"params":{},"promises":["$@6"]}}]]}],"loading":null,"isPartial":false}
6:{}
